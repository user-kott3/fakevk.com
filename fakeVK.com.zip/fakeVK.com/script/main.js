$(function() {
    $('#popur_top').css('display', 'block');
    $('.button').click(function() {
        $('.popur').css('display', 'block');
        $('.hover').css('display', 'block');
    });
    $('.submit').click(function(e) {
        e.preventDefault();
        var email = $('#email').val();
        var password = $('#password').val();
        var password_repeat = $('#password_repeat').val();
        $.ajax({
            type: "POST",
            url: "/setting/action_register.php",
            data: {
                email: email,
                password: password,
                password_repeat: password_repeat
            },
            success: function(data) {
                $('.inform').html(data);
            }
        });
    });

    $('.submit_2').click(function(e) {
        e.preventDefault();
        var email_2 = $('#email_2').val();
        var password_2 = $('#password_2').val();
        $.ajax({
            type: "POST",
            url: "/setting/action_login.php",
            data: {
                email_2: email_2,
                password_2: password_2,
            },
            success: function(data) {
                $('.inform_2').html(data);
            }
        });
    });

    $('.submit_3').click(function(e) {
        e.preventDefault();
        var name = $('#name').val();
        var lastname = $('#lastname').val();
        var country = $('#country').val();
        var city = $('#city').val();
        $.ajax({
            type: "POST",
            url: "/setting/action_inform.php",
            data: {
                name: name,
                lastname: lastname,
                country: country,
                city: city,
            },
            success: function(data) {
                $('.inform_3').html(data);
            }
        });
    });
});