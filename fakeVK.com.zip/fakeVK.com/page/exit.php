<?
    if (empty($_SESSION['email']) or empty($_SESSION['password'])) {
        exit("Доступ на эту страницу разрешен только зарегистрированным пользователям");
    }

    unset($_SESSION['email']);
    unset($_SESSION['password']);
    unset($_SESSION['id']);

    exit("<meta http-equiv='refresh' content='0 URL=/index'>");
?>