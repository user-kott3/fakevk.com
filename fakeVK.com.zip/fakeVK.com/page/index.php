<? top("Социальная сеть"); ?>
<header class="header">Шапка</header>
<div class="leftcol"><?include('form/login_form.php'); include('form/register_form.php');?></div>
<div class="content">
    <? include("html/content.php"); ?>
</div>
<? bottom(); ?>