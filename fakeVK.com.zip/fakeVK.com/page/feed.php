<? top("Новости"); ?>

<?
if (!$_SESSION['email'] AND !$_SESSION['password']) {

} else {
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $q = "SELECT id, name, lastname, country, city FROM users WHERE id='{$_SESSION['id']}'";
    $result = mysqli_query($conn, $q);
    $r = mysqli_fetch_array($result);
    if ($r['name'] == '' or $r['lastname'] == '' or $r['country'] == '') {
        include("form/inform_form.php");
    }
}
?>

<header class="header">Шапка</header>
<div class="leftcol"></div>
<div class="feed">
    <h1>Новости</h1>
</div>
<div class="rightcol">
    
</div>
<? bottom(); ?>