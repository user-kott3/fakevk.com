<?
include "../bd.php";
session_start();


if (!$_SESSION['email'] AND !$_SESSION['password']) {

} else {
    $id = $_SESSION['id'];
    $email = $_SESSION['email'];
    $password = $_SESSION['password'];
    $q = "SELECT id, name, lastname, country, city FROM users WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $q);
    $r = mysqli_fetch_array($result);
}
if (isset($_POST)) {
    if (empty($_POST['name'])) {
        echo"<b><span style='text-align:center; color: #f00;'>Введите ваше Имя</span></b>";
    }
    elseif (empty($_POST['lastname'])) {
        echo"<b><span style='text-align:center; color: #f00;'>Введите вашу фамилию</span></b>";
    }
    elseif (empty($_POST['country'])) {
        echo"<b><span style='text-align:center; color: #f00;'>Введите вашу страну</span></b>";
    } else {
        $name=htmlspecialchars($_POST["name"]);
        $lastname=htmlspecialchars($_POST["lastname"]);
        $country=htmlspecialchars($_POST["country"]);
        $city=htmlspecialchars($_POST["city"]);
                          
        mysqli_query($conn, "UPDATE users SET name='$name', lastname='$lastname', country='$country', city='$city' WHERE id='{$_SESSION['id']}'");
        exit("<meta http-equiv='Refresh' content='0; URL=feed'>");
    }
}
?>