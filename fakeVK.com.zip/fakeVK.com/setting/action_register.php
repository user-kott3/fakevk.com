<?
if (isset($_POST)) {
    if (empty($_POST['email'])) {
        echo "<b><span style='text-align:center; color: #f00;'>Введите ваш E-mail</span></b>";

    } elseif (!preg_match("/[0-9a-z]+@[a-z]/", $_POST['email'])) {
        echo "<b><span style='text-align:center; color: #f00;'>E-mail имеет недопустимый формат</span></b>";
    } elseif (empty($_POST['password'])) {
        echo "<b><span style='text-align:center; color: #f00;'>Придумайте пароль</span></b>";
    } elseif (!preg_match("/\A(\w){6,20}\Z/", $_POST['password'])) {
        echo "<b><span style='text-align:center; color: #f00;'>Пароль не должен быть меньше 6 символов и превышать 20</span></b>";
    } elseif (empty($_POST['password_repeat'])) {
        echo "<b><span style='text-align:center; color: #f00;'>Повторите ваш пароль</span></b>";
    } elseif ($_POST['password'] != $_POST['password_repeat']) {
        echo "<b><span style='text-align:center; color: #f00;'>пароли не совпадают</span></b>";
    } else {
        $email = htmlspecialchars($_POST['email']);
        $password = htmlspecialchars($_POST['password']);
        $password_repeat = htmlspecialchars($_POST['password_repeat']);
        $data = date("d-m-y в H:i");
        $mdPassword = (md5($_POST['password']));
        $ip = $_SERVER['REMOTE_ADDR'];

        $servername = "localhost";
        $database = "fakevk";
        $username = "root";
        $password = "root";

        $conn = mysqli_connect($servername, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $query = "SELECT id FROM users WHERE email='$email'";
        $sql = mysqli_query($conn, $query) or die (mysqli_error($conn));
        if (mysqli_num_rows($sql) > 0) {
            echo "<b><span style='text-align:center; color: #ff0000;'>Такой E-mail уже зарегистрирован!</span></b>";
        } else {
            $q = "INSERT INTO users(email, password, data, ip, activation) VALUES('$email', '$mdPassword', '$data', '$ip', '0')";
            $result = mysqli_query($conn, $q) or die (mysqli_error($conn));

            $user = "SELECT id FROM users WHERE email='$email'";
            $activ = mysqli_query($conn, $user);
            $id_activ = mysqli_fetch_array($activ);
            $activation=md5($id_activ['id']);
            $subject="Подтверждение регистрации";
            $message="Здравствуйте, спасибо за регистрацию на сайте fakeVK.com \n Ваш E-mail ".$email."\n
            Для того чтобы войти в свой аккаунт его нужно активировать, чтобы активировать ваш аккаунт,
            перейдите по ссылке: http://fakevk.com/index?email=".$email."&act=".$activation."\n\n
            С уважением администрация сайта fakeVK.com ";
            mail($email, $subject, $message, "Content-type:text/plane Charset=utf-8\n\n");

            exit("<b><span style='text-align:center; color: #0f0;'>Вы успешно зарегистрировались, на ваш E-mail отправленна ссылка для активации вашего аккаунта</span></b>");
        }
    }
}

?>