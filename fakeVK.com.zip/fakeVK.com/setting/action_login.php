<?
session_start();
if (isset($_POST)) {
    if(empty($_POST['email_2'])) {
        $email_2 = $_POST['email_2'];
        if ($email_2 == '') {
            unset($email_2);
            exit("<b><span style='text-align:center; color: #f00;'>Введите ваш E-mail</span></b>");
        }
    }

    elseif(empty($_POST['password_2'])) {
        $password_2 = $_POST['password_2'];
        if ($password_2 == '') {
            unset($password_2);
            exit("<b><span style='text-align:center; color: #f00;'>Введите ваш пароль</span></b>");
        }
    }
    $email_2 = stripcslashes($email_2);
    $email_2 = htmlspecialchars($email_2);
    $email_2 = trim($email_2);

    $password_2 = stripcslashes($password_2);
    $password_2 = htmlspecialchars($password_2);
    $password_2 = trim($password_2);

    $email = $_POST['email_2'];
    $password = $_POST['password_2'];
    $password = md5($password);

    $servername = "localhost";
        $database = "fakevk";
        $username = "root";
        $password = "root";

        $conn = mysqli_connect($servername, $username, $password, $database);

        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

    $user = "SELECT id FROM users WHERE email='$email' AND activation='1'";
    $result = mysqli_query($conn, $user);
    $id_user = mysqli_fetch_array($result);
    if (empty($id_user['id'])) {
        exit("<b><span style='text-align:center; color: #f00;'>E-mail или пароль неверные, или ваш аккаунт неактивированный</span></b>");
    } else {
        $_SESSION['email'] = $email;
        $_SESSION['password'] = $password;
        $_SESSION['id'] = $id_user['id'];
        echo"<meta http-equiv='refresh' content='0 URL=feed'>";
    }

    if (setcookie('email', $_POST['password'], strtotime("+30 days"), '/')) {
        setcookie('email', $_POST['email'], time()+99999999);
        setcookie('password', $_POST['password'], time()+99999999);
    }
}
?>