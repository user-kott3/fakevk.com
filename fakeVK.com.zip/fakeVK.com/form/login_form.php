<?
    include "./bd.php";
    if (isset($_GET['act']) AND isset($_GET['email'])) {
        $act = $_GET['act'];
        $act = htmlspecialchars($act);
        $act = stripcslashes($act);

        $email = $_GET['email'];
        $email = htmlspecialchars($email);
        $email = stripcslashes($email);
        $activ = "SELECT id FROM users WHERE email='$email'";
        $result = mysqli_query($conn, $activ);
        $id_activ = mysqli_fetch_array($result);
        $activation = md5($id_activ['id']);
        if ($activation == $act) {
            mysqli_query($conn, "UPDATE users SET activation='1' WHERE email='$email'");
            echo "<b><span style='text-align:center; color: #0f0;'>Вы успешно активированы! Теперь вы сможете войти в свой аккаунт под своим E-mail и паролем.</span></b>";
        }
    }
?>






<div class="login">
    <div class="inform_2"></div>
    <form action="javascript:void(0)" method="post">
        <b>E-mail:</b>
        <input type="email" name="email_2" id="email_2"> <br>

        <b>Пароль:</b>
        <input type="password" name="password_2" id="password_2"> <br>
        
        <input type="submit" name="enter" class="submit_2" value="Войти">
    </form>
</div>

<button class="button">Зарегистрироваться</button>