<div class="popur">
    <div class="popur_top"><span>Моментальная регистрация.</span>
        <a href="">&times</a>
    </div>
    <div class="register">
    <p>Пожалуйста! Укажите ваш E-mail и пароль</p>
    <center>На указанный E-mail будет отправлена ссылка для активации вашего аккаунта.</center> <br>
    <div class="inform"></div>
    <form action="javascript:void(0)" method="post">
    <b>Введите ваш E-mail:</b> <br>
        <input type="email" name="email" id="email"> <br><br>
        <b>Введите ваш пароль:</b> <br>
        <input type="password" name="password" id="password"> <br><br>
        <b>Повторите ваш пароль:</b> <br>
        <input type="password" name="password_repeat" id="password_repeat"> <br><br>
        <input type="submit" name="enter" value="Зарегистрироваться" class="submit">
    </form>
</div>
</div>

<div class="hover"></div>