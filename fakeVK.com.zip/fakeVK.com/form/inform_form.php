<div id="popur_top">
    <div class="popur_top_2">

    </div>
    <p>Введите ваши данные</p>
    <div class="inform_3"></div>
    <form action="javascript:void(0)" method="post">
        <b>Ваше имя</b>
        <input type="text" name="name" id="name"><br><br>
        <b>Ваша Фамилия</b>
        <input type="text" name="lastname" id="lastname"><br><br>
        <b>Ваша страна</b>
        <select name="country" id="country">
            <option value="0" disabled selected>Страна</option>
            <option value="1">Россия</option>
            <option value="2">США</option>
            <option value="3">Китай</option>
            <option value="4">Украина</option>
        </select><br><br>
        <b>Ваш город</b>
        <input type="text" name="city" id="city" placeholder="Необязательно к заполнению"><br><br>
        <input type="submit" class="submit_3" value="Сохранить">
    </form>
</div>